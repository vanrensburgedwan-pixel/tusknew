import { createBrowserRouter } from "react-router";
import Home from "../pages/Home";
import About from "../pages/About";
import Services from "../pages/Services";
import Projects from "../pages/Projects";
import Innovation from "../pages/Innovation";
import Contact from "../pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/about",
    Component: About,
  },
  {
    path: "/services",
    Component: Services,
  },
  {
    path: "/projects",
    Component: Projects,
  },
  {
    path: "/innovation",
    Component: Innovation,
  },
  {
    path: "/contact",
    Component: Contact,
  },
]);
