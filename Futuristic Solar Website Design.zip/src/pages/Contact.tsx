import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Send, MessageSquare, Clock } from 'lucide-react';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';
import { useState } from 'react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    projectType: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <div className="min-h-screen bg-[#0A0A1A]">
      <Navigation />
      
      {/* Hero with Video Background */}
      <section className="relative pt-32 pb-16 px-4 overflow-hidden">
        {/* Background Video/Image */}
        <div className="absolute inset-0 z-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1681064442359-be45e8d72498?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjBzb2xhciUyMGVuZXJneXxlbnwxfHx8fDE3NjQ0MDg1ODd8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Solar farm at sunrise"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A1A]/80 via-[#0A0A1A]/90 to-[#0A0A1A]"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="mb-6 text-white">
              <span className="block">Let's Build Your</span>
              <span className="bg-gradient-to-r from-[#FFB800] via-[#C0FF00] to-[#00C2FF] bg-clip-text text-transparent">
                Solar Future Together
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Ready to make the switch to clean energy? Get in touch with our team of experts for a free consultation.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="relative py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Left: Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="lg:col-span-2 space-y-8"
            >
              <div>
                <h2 className="mb-6 text-white">Get in Touch</h2>
                <p className="text-gray-400 mb-8">
                  Our team is available 24/7 to answer your questions and help you design the perfect solar solution.
                </p>
              </div>

              {/* Contact Methods */}
              <div className="space-y-6">
                {[
                  { 
                    icon: Phone, 
                    label: 'Phone', 
                    value: '+1 (555) 123-4567', 
                    subtext: 'Mon-Fri, 8am-8pm PST',
                    color: '#C0FF00' 
                  },
                  { 
                    icon: Mail, 
                    label: 'Email', 
                    value: 'hello@solarnext.com', 
                    subtext: 'We reply within 2 hours',
                    color: '#00C2FF' 
                  },
                  { 
                    icon: MapPin, 
                    label: 'Headquarters', 
                    value: '123 Solar Street, San Francisco, CA 94102', 
                    subtext: 'Visit our showroom',
                    color: '#FFB800' 
                  },
                ].map((contact, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1, duration: 0.6 }}
                    className="group relative p-6 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-2xl hover:border-white/20 transition-all duration-300"
                  >
                    <motion.div
                      className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{
                        background: `radial-gradient(circle at center, ${contact.color}10, transparent)`,
                      }}
                    />
                    <div className="relative z-10 flex items-start gap-4">
                      <div
                        className="p-3 rounded-xl border"
                        style={{
                          backgroundColor: `${contact.color}15`,
                          borderColor: `${contact.color}30`,
                        }}
                      >
                        <contact.icon size={24} style={{ color: contact.color }} />
                      </div>
                      <div className="flex-1">
                        <div className="text-sm text-gray-500 mb-1">{contact.label}</div>
                        <div className="text-white mb-1">{contact.value}</div>
                        <div className="text-xs text-gray-600">{contact.subtext}</div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Quick Links */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="p-8 bg-gradient-to-br from-white/5 to-transparent border border-[#C0FF00]/20 rounded-3xl"
              >
                <h4 className="mb-6 text-white">Quick Access</h4>
                <div className="space-y-4">
                  {[
                    { icon: MessageSquare, text: 'Live Chat', subtext: 'Chat with our team now' },
                    { icon: Clock, text: 'Schedule a Call', subtext: 'Book a consultation' },
                  ].map((item, i) => (
                    <button
                      key={i}
                      className="w-full p-4 bg-white/5 border border-white/10 rounded-xl hover:border-[#C0FF00]/30 hover:bg-white/10 transition-all duration-300 flex items-center gap-4 text-left"
                    >
                      <div className="p-2 bg-[#C0FF00]/10 border border-[#C0FF00]/30 rounded-lg">
                        <item.icon size={20} className="text-[#C0FF00]" />
                      </div>
                      <div>
                        <div className="text-white">{item.text}</div>
                        <div className="text-xs text-gray-500">{item.subtext}</div>
                      </div>
                    </button>
                  ))}
                </div>

                {/* QR Code Placeholder */}
                <div className="mt-6 pt-6 border-t border-white/10">
                  <div className="text-center">
                    <div className="w-32 h-32 mx-auto mb-4 bg-white/10 border border-white/20 rounded-2xl flex items-center justify-center">
                      <div className="w-24 h-24 bg-gradient-to-br from-[#C0FF00]/20 to-[#00C2FF]/20 rounded-xl"></div>
                    </div>
                    <p className="text-sm text-gray-400">Scan for WhatsApp</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>

            {/* Right: Glassmorphic Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="lg:col-span-3"
            >
              <div className="relative p-8 lg:p-12 bg-gradient-to-br from-white/10 to-white/5 border border-white/10 rounded-[3rem] backdrop-blur-xl overflow-hidden">
                {/* Animated Border Glow */}
                <motion.div
                  className="absolute inset-0 rounded-[3rem]"
                  animate={{
                    boxShadow: [
                      '0 0 20px rgba(192, 255, 0, 0)',
                      '0 0 60px rgba(192, 255, 0, 0.3)',
                      '0 0 20px rgba(192, 255, 0, 0)',
                    ],
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                />

                <form onSubmit={handleSubmit} className="relative z-10 space-y-6">
                  <div className="mb-8">
                    <h3 className="mb-2 text-white">Request a Free Quote</h3>
                    <p className="text-gray-400">Fill out the form and we'll get back to you within 24 hours</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block mb-2 text-gray-300">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:border-[#C0FF00] focus:outline-none focus:ring-2 focus:ring-[#C0FF00]/20 transition-all duration-300"
                        placeholder="John Doe"
                        required
                      />
                    </div>

                    <div>
                      <label htmlFor="email" className="block mb-2 text-gray-300">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:border-[#C0FF00] focus:outline-none focus:ring-2 focus:ring-[#C0FF00]/20 transition-all duration-300"
                        placeholder="john@example.com"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="phone" className="block mb-2 text-gray-300">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:border-[#C0FF00] focus:outline-none focus:ring-2 focus:ring-[#C0FF00]/20 transition-all duration-300"
                        placeholder="+1 (555) 123-4567"
                        required
                      />
                    </div>

                    <div>
                      <label htmlFor="projectType" className="block mb-2 text-gray-300">
                        Project Type *
                      </label>
                      <select
                        id="projectType"
                        name="projectType"
                        value={formData.projectType}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:border-[#C0FF00] focus:outline-none focus:ring-2 focus:ring-[#C0FF00]/20 transition-all duration-300"
                        required
                      >
                        <option value="" className="bg-[#0A0A1A]">Select a type</option>
                        <option value="residential" className="bg-[#0A0A1A]">Residential</option>
                        <option value="commercial" className="bg-[#0A0A1A]">Commercial</option>
                        <option value="industrial" className="bg-[#0A0A1A]">Industrial</option>
                        <option value="other" className="bg-[#0A0A1A]">Other</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block mb-2 text-gray-300">
                      Project Details *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={6}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:border-[#C0FF00] focus:outline-none focus:ring-2 focus:ring-[#C0FF00]/20 transition-all duration-300 resize-none"
                      placeholder="Tell us about your solar energy needs, property size, current energy usage, etc."
                      required
                    />
                  </div>

                  <motion.button
                    type="submit"
                    className="group w-full py-4 bg-gradient-to-r from-[#C0FF00] via-[#FFB800] to-[#00C2FF] text-[#0A0A1A] rounded-xl overflow-hidden relative transition-all duration-300 hover:shadow-[0_0_50px_rgba(192,255,0,0.8)]"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <span className="relative z-10 flex items-center justify-center gap-2">
                      Send Message
                      <Send size={20} className="group-hover:translate-x-2 transition-transform duration-300" />
                    </span>
                  </motion.button>

                  <p className="text-center text-sm text-gray-500">
                    By submitting this form, you agree to our privacy policy and terms of service.
                  </p>
                </form>

                {/* Corner Glows */}
                <div className="absolute -top-20 -left-20 w-40 h-40 bg-[#C0FF00]/10 rounded-full blur-[100px]"></div>
                <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-[#00C2FF]/10 rounded-full blur-[100px]"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Map Section Placeholder */}
      <section className="relative py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative h-96 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-3xl overflow-hidden"
          >
            {/* Map Placeholder with Animated Sunlight Tracking */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <MapPin size={48} className="text-[#C0FF00] mx-auto mb-4" />
                <h4 className="text-white mb-2">Service Coverage Map</h4>
                <p className="text-gray-400">Real-time sunlight tracking across our service regions</p>
              </div>
            </div>

            {/* Animated Grid Overlay */}
            <div className="absolute inset-0 opacity-20">
              <div className="w-full h-full bg-[linear-gradient(rgba(192,255,0,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(192,255,0,0.2)_1px,transparent_1px)] bg-[size:50px_50px]"></div>
            </div>

            {/* Pulsing Dots for Locations */}
            {[
              { top: '30%', left: '20%' },
              { top: '50%', left: '50%' },
              { top: '40%', left: '70%' },
              { top: '60%', left: '35%' },
            ].map((pos, i) => (
              <motion.div
                key={i}
                className="absolute w-4 h-4"
                style={{ top: pos.top, left: pos.left }}
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.6, 1, 0.6],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.3,
                }}
              >
                <div className="w-full h-full rounded-full bg-[#C0FF00] shadow-[0_0_20px_rgba(192,255,0,0.8)]"></div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
