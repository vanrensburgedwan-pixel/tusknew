import { motion } from 'motion/react';
import { Brain, Leaf, Zap, Award, Users, Globe } from 'lucide-react';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

const milestones = [
  { year: '2020', title: 'Foundation', desc: 'Company established with vision for sustainable energy' },
  { year: '2021', title: 'AI Integration', desc: 'Launched first AI-powered monitoring system' },
  { year: '2022', title: 'Global Expansion', desc: 'Expanded operations to 15 countries' },
  { year: '2023', title: '10K Installations', desc: 'Reached milestone of 10,000 solar installations' },
  { year: '2024', title: 'Innovation Award', desc: 'Recognized as leading renewable energy innovator' },
  { year: '2025', title: 'Net Zero', desc: 'Achieved carbon neutral operations' },
];

export default function About() {
  return (
    <div className="min-h-screen bg-[#0A0A1A]">
      <Navigation />
      
      {/* Hero Section with Split Screen */}
      <section className="relative pt-32 pb-24 px-4 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left: Text Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.6 }}
              >
                <span className="px-4 py-2 bg-[#C0FF00]/10 border border-[#C0FF00]/30 rounded-full text-[#C0FF00]">
                  About SolarNext
                </span>
              </motion.div>

              <h1 className="text-white">
                Harnessing the Sun
                <br />
                <span className="bg-gradient-to-r from-[#FFB800] to-[#C0FF00] bg-clip-text text-transparent">
                  with Intelligence
                </span>
              </h1>

              <p className="text-xl text-gray-300">
                We're not just installing solar panels — we're engineering the future of renewable energy through AI, innovation, and sustainable practices.
              </p>

              <div className="space-y-4">
                {[
                  { icon: Brain, text: 'AI-Powered Energy Optimization' },
                  { icon: Leaf, text: 'Committed to Zero Carbon Future' },
                  { icon: Zap, text: 'Industry-Leading Efficiency' },
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + i * 0.1, duration: 0.6 }}
                    className="flex items-center gap-4"
                  >
                    <div className="p-3 bg-[#C0FF00]/10 border border-[#C0FF00]/30 rounded-lg">
                      <item.icon size={20} className="text-[#C0FF00]" />
                    </div>
                    <span className="text-gray-300">{item.text}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Right: Video/Image Background */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative h-[600px] rounded-3xl overflow-hidden"
            >
              <div className="absolute inset-0">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1681064442359-be45e8d72498?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjBzb2xhciUyMGVuZXJneXxlbnwxfHx8fDE3NjQ0MDg1ODd8MA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Solar panels at sunset"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A1A] via-transparent to-transparent"></div>
              </div>

              {/* Floating Stats */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { value: '50K+', label: 'Installations' },
                    { value: '99.9%', label: 'Uptime' },
                    { value: '30+', label: 'Countries' },
                    { value: '24/7', label: 'Support' },
                  ].map((stat, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 1 + i * 0.1, duration: 0.6 }}
                      className="p-6 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl text-center"
                    >
                      <div className="text-3xl text-[#C0FF00] mb-1">{stat.value}</div>
                      <div className="text-sm text-gray-300">{stat.label}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#C0FF00]/10 to-[#00C2FF]/10 mix-blend-overlay"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="relative py-24 px-4 bg-gradient-to-b from-[#0A0A1A] to-[#0f0f24]">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="mb-4 text-white">Our Core Values</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Guided by innovation, driven by sustainability
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Globe,
                title: 'Global Impact',
                desc: 'Creating positive environmental change on a worldwide scale',
                color: '#C0FF00',
              },
              {
                icon: Users,
                title: 'Customer First',
                desc: 'Delivering exceptional service and support at every step',
                color: '#00C2FF',
              },
              {
                icon: Award,
                title: 'Excellence',
                desc: 'Committed to the highest standards in quality and innovation',
                color: '#FFB800',
              },
            ].map((value, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2, duration: 0.6 }}
                className="group relative p-8 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-3xl hover:border-white/20 transition-all duration-500"
              >
                <motion.div
                  className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background: `radial-gradient(circle at center, ${value.color}15, transparent)`,
                  }}
                />
                
                <div className="relative z-10">
                  <div
                    className="inline-flex p-4 rounded-2xl mb-6 group-hover:shadow-[0_0_30px] transition-all duration-500"
                    style={{
                      backgroundColor: `${value.color}15`,
                      borderColor: `${value.color}30`,
                      border: '1px solid',
                      boxShadow: `0 0 0 ${value.color}00`,
                    }}
                  >
                    <value.icon size={32} style={{ color: value.color }} />
                  </div>
                  <h3 className="mb-3 text-white">{value.title}</h3>
                  <p className="text-gray-400">{value.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Animated Timeline */}
      <section className="relative py-24 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="mb-4 bg-gradient-to-r from-[#C0FF00] to-[#00C2FF] bg-clip-text text-transparent">
              Our Journey
            </h2>
            <p className="text-gray-400">Milestones in sustainable innovation</p>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-[#C0FF00] via-[#00C2FF] to-[#FFB800]"></div>

            {/* Timeline Items */}
            <div className="space-y-12">
              {milestones.map((milestone, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.6 }}
                  className={`flex items-center gap-8 ${
                    i % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                  }`}
                >
                  <div className={`flex-1 ${i % 2 === 0 ? 'text-right' : 'text-left'}`}>
                    <div className="p-6 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-2xl inline-block hover:border-[#C0FF00]/30 transition-all duration-300">
                      <div className="text-[#C0FF00] mb-2">{milestone.year}</div>
                      <h4 className="text-white mb-2">{milestone.title}</h4>
                      <p className="text-gray-400">{milestone.desc}</p>
                    </div>
                  </div>

                  {/* Center Dot */}
                  <div className="relative z-10">
                    <motion.div
                      className="w-4 h-4 rounded-full bg-[#C0FF00] border-4 border-[#0A0A1A]"
                      whileInView={{ scale: [1, 1.5, 1] }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 + 0.3, duration: 0.6 }}
                    >
                      <div className="absolute inset-0 rounded-full bg-[#C0FF00] animate-ping opacity-75"></div>
                    </motion.div>
                  </div>

                  <div className="flex-1"></div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
