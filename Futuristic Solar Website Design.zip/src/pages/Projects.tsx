import { motion } from 'motion/react';
import { MapPin, Zap, TrendingDown, Calendar, ExternalLink } from 'lucide-react';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { useState } from 'react';

const projects = [
  {
    id: 1,
    title: 'Skyline Residence',
    location: 'San Francisco, CA',
    category: 'Residential',
    image: 'https://images.unsplash.com/photo-1466904224516-9f8b3ebcbccb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBzb2xhcnxlbnwxfHx8fDE3NjQ0MDgwNzR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    power: '25 kW',
    carbonReduction: '92%',
    completed: '2024',
    description: 'Modern smart home powered entirely by solar with battery backup system.',
  },
  {
    id: 2,
    title: 'TechCorp Campus',
    location: 'Austin, TX',
    category: 'Commercial',
    image: 'https://images.unsplash.com/photo-1726795867795-32bc9872a44a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzb2xhciUyMHBhbmVscyUyMGJ1aWxkaW5nfGVufDF8fHx8MTc2NDQwODU4N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    power: '500 kW',
    carbonReduction: '95%',
    completed: '2024',
    description: 'Enterprise-grade installation powering 200,000 sq ft of office space.',
  },
  {
    id: 3,
    title: 'Green Valley Farm',
    location: 'Portland, OR',
    category: 'Agricultural',
    image: 'https://images.unsplash.com/photo-1725308659447-bf1b10f6635a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMGZhcm0lMjBhZXJpYWx8ZW58MXx8fHwxNzY0NDA4NTg3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    power: '1.2 MW',
    carbonReduction: '98%',
    completed: '2023',
    description: 'Large-scale solar farm generating clean energy for 500+ homes.',
  },
  {
    id: 4,
    title: 'Metro Industrial Park',
    location: 'Denver, CO',
    category: 'Industrial',
    image: 'https://images.unsplash.com/photo-1723177548474-b58ada59986b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwc29sYXIlMjBpbnN0YWxsYXRpb258ZW58MXx8fHwxNzY0MzQ2MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    power: '750 kW',
    carbonReduction: '89%',
    completed: '2024',
    description: 'Manufacturing facility achieving near-zero energy costs.',
  },
  {
    id: 5,
    title: 'Oceanview Apartments',
    location: 'Miami, FL',
    category: 'Multi-Family',
    image: 'https://images.unsplash.com/photo-1616745207210-a98414926a3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzY0NDA4MDczfDA&ixlib=rb-4.1.0&q=80&w=1080',
    power: '150 kW',
    carbonReduction: '87%',
    completed: '2023',
    description: '48-unit apartment complex with shared solar energy system.',
  },
  {
    id: 6,
    title: 'Sunset Energy Hub',
    location: 'Phoenix, AZ',
    category: 'Utility Scale',
    image: 'https://images.unsplash.com/photo-1681064442359-be45e8d72498?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjBzb2xhciUyMGVuZXJneXxlbnwxfHx8fDE3NjQ0MDg1ODd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    power: '5 MW',
    carbonReduction: '99%',
    completed: '2024',
    description: 'Utility-scale solar installation powering 2,000+ homes.',
  },
];

const categories = ['All', 'Residential', 'Commercial', 'Industrial', 'Agricultural', 'Multi-Family', 'Utility Scale'];

export default function Projects() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);

  const filteredProjects = selectedCategory === 'All' 
    ? projects 
    : projects.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen bg-[#0A0A1A]">
      <Navigation />
      
      {/* Hero */}
      <section className="relative pt-32 pb-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="mb-6 text-white">
              <span className="block">Our Portfolio of</span>
              <span className="bg-gradient-to-r from-[#FFB800] via-[#C0FF00] to-[#00C2FF] bg-clip-text text-transparent">
                Solar Excellence
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-12">
              Explore our completed installations and see how we're transforming energy landscapes worldwide.
            </p>

            {/* Category Filter */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="flex flex-wrap justify-center gap-3"
            >
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-2 rounded-full border transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-[#C0FF00] text-[#0A0A1A] border-[#C0FF00] shadow-[0_0_20px_rgba(192,255,0,0.6)]'
                      : 'bg-white/5 text-gray-400 border-white/10 hover:border-[#C0FF00]/30 hover:text-[#C0FF00]'
                  }`}
                >
                  {category}
                </button>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="relative py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                onMouseEnter={() => setHoveredProject(project.id)}
                onMouseLeave={() => setHoveredProject(null)}
                className="group relative h-[500px] rounded-3xl overflow-hidden cursor-pointer"
              >
                {/* Image */}
                <div className="absolute inset-0">
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A1A] via-[#0A0A1A]/60 to-transparent"></div>
                </div>

                {/* Glowing Border Animation */}
                <motion.div
                  className="absolute inset-0 rounded-3xl border-2 border-transparent"
                  animate={hoveredProject === project.id ? {
                    borderColor: ['rgba(192, 255, 0, 0)', 'rgba(192, 255, 0, 0.6)', 'rgba(192, 255, 0, 0)'],
                    boxShadow: [
                      'inset 0 0 0px rgba(192, 255, 0, 0)',
                      'inset 0 0 30px rgba(192, 255, 0, 0.3)',
                      'inset 0 0 0px rgba(192, 255, 0, 0)',
                    ],
                  } : {}}
                  transition={{ duration: 2, repeat: Infinity }}
                />

                {/* Content */}
                <div className="relative h-full flex flex-col justify-between p-8 z-10">
                  {/* Category Badge */}
                  <div>
                    <span className="inline-block px-4 py-1 bg-[#C0FF00]/20 border border-[#C0FF00]/40 rounded-full text-[#C0FF00] text-sm backdrop-blur-sm">
                      {project.category}
                    </span>
                  </div>

                  {/* Bottom Info */}
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-white mb-2">{project.title}</h3>
                      <div className="flex items-center gap-2 text-gray-400 text-sm mb-4">
                        <MapPin size={16} />
                        <span>{project.location}</span>
                      </div>
                      
                      <motion.p
                        className="text-gray-300 text-sm mb-4"
                        initial={{ opacity: 0, height: 0 }}
                        animate={hoveredProject === project.id ? { opacity: 1, height: 'auto' } : { opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        {project.description}
                      </motion.p>
                    </div>

                    {/* Metrics */}
                    <motion.div
                      className="grid grid-cols-3 gap-4"
                      initial={{ opacity: 0, y: 20 }}
                      animate={hoveredProject === project.id ? { opacity: 1, y: 0 } : { opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="p-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl">
                        <Zap size={16} className="text-[#C0FF00] mb-1" />
                        <div className="text-sm text-white">{project.power}</div>
                        <div className="text-xs text-gray-500">Generated</div>
                      </div>
                      <div className="p-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl">
                        <TrendingDown size={16} className="text-[#00C2FF] mb-1" />
                        <div className="text-sm text-white">{project.carbonReduction}</div>
                        <div className="text-xs text-gray-500">CO₂ Cut</div>
                      </div>
                      <div className="p-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl">
                        <Calendar size={16} className="text-[#FFB800] mb-1" />
                        <div className="text-sm text-white">{project.completed}</div>
                        <div className="text-xs text-gray-500">Year</div>
                      </div>
                    </motion.div>

                    {/* View More Button */}
                    <motion.button
                      className="w-full py-3 bg-gradient-to-r from-[#C0FF00] to-[#00C2FF] text-[#0A0A1A] rounded-xl flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      View Details
                      <ExternalLink size={18} />
                    </motion.button>
                  </div>
                </div>

                {/* Hover Glow Effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-t from-[#C0FF00]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative p-12 bg-gradient-to-br from-white/10 to-white/5 border border-[#C0FF00]/30 rounded-[3rem] overflow-hidden"
          >
            <div className="relative z-10 text-center mb-12">
              <h2 className="mb-4 text-white">Impact By Numbers</h2>
              <p className="text-gray-400">Our collective contribution to a sustainable future</p>
            </div>

            <div className="relative z-10 grid md:grid-cols-4 gap-8">
              {[
                { value: '50,000+', label: 'Solar Panels Installed', color: '#C0FF00' },
                { value: '127 MW', label: 'Total Capacity', color: '#00C2FF' },
                { value: '94%', label: 'Avg Carbon Reduction', color: '#FFB800' },
                { value: '15,000+', label: 'Homes Powered', color: '#C0FF00' },
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.6 }}
                  className="text-center"
                >
                  <div
                    className="text-5xl mb-2"
                    style={{ color: stat.color }}
                  >
                    {stat.value}
                  </div>
                  <div className="text-gray-400">{stat.label}</div>
                </motion.div>
              ))}
            </div>

            {/* Animated Background */}
            <motion.div
              className="absolute inset-0 opacity-30"
              animate={{
                background: [
                  'radial-gradient(circle at 20% 30%, rgba(192, 255, 0, 0.15), transparent 40%)',
                  'radial-gradient(circle at 80% 70%, rgba(0, 194, 255, 0.15), transparent 40%)',
                  'radial-gradient(circle at 20% 30%, rgba(192, 255, 0, 0.15), transparent 40%)',
                ],
              }}
              transition={{ duration: 8, repeat: Infinity }}
            />
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
