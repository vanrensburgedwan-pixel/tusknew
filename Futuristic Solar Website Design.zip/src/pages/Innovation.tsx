import { motion } from 'motion/react';
import { Brain, Cpu, Activity, Wifi, CloudRain, TrendingUp, Zap, Battery } from 'lucide-react';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';
import { useState, useEffect } from 'react';

export default function Innovation() {
  const [energyFlow, setEnergyFlow] = useState(78);
  const [gridBalance, setGridBalance] = useState(92);
  const [efficiency, setEfficiency] = useState(95);

  useEffect(() => {
    const interval = setInterval(() => {
      setEnergyFlow(prev => Math.max(65, Math.min(95, prev + (Math.random() - 0.5) * 5)));
      setGridBalance(prev => Math.max(85, Math.min(98, prev + (Math.random() - 0.5) * 3)));
      setEfficiency(prev => Math.max(90, Math.min(99, prev + (Math.random() - 0.5) * 2)));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A1A]">
      <Navigation />
      
      {/* Hero */}
      <section className="relative pt-32 pb-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block px-6 py-2 bg-gradient-to-r from-[#C0FF00]/20 to-[#00C2FF]/20 border border-[#C0FF00]/30 rounded-full text-[#C0FF00] mb-6">
              Powered by AI & Sustainability
            </div>
            <h1 className="mb-6 text-white">
              <span className="block">The Intelligence Behind</span>
              <span className="bg-gradient-to-r from-[#00C2FF] via-[#C0FF00] to-[#FFB800] bg-clip-text text-transparent">
                Next-Gen Solar
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Experience the future of energy management with our AI-powered monitoring, IoT integration, and predictive analytics platform.
            </p>
          </motion.div>
        </div>
      </section>

      {/* 3D Holographic Dashboard */}
      <section className="relative py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* Main Dashboard Container */}
            <div className="relative p-8 lg:p-12 bg-gradient-to-br from-white/10 to-white/5 border border-[#C0FF00]/30 rounded-[3rem] overflow-hidden backdrop-blur-xl">
              {/* Scanning Line Effect */}
              <motion.div
                className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#C0FF00] to-transparent"
                initial={{ top: 0, opacity: 0 }}
                animate={{ top: '100%', opacity: [0, 1, 1, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
              />

              {/* Header */}
              <div className="flex items-center justify-between mb-12">
                <div className="flex items-center gap-4">
                  <div className="w-4 h-4 rounded-full bg-[#C0FF00] animate-pulse shadow-[0_0_20px_rgba(192,255,0,0.8)]"></div>
                  <h3 className="text-white">Live Energy Dashboard</h3>
                </div>
                <div className="flex items-center gap-2 text-[#00C2FF]">
                  <Activity className="animate-pulse" size={20} />
                  <span>Real-time Monitoring</span>
                </div>
              </div>

              {/* Main Grid */}
              <div className="grid lg:grid-cols-3 gap-8 mb-8">
                {/* Energy Flow Gauge */}
                <motion.div
                  className="lg:col-span-2"
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <div className="p-8 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-3xl">
                    <h4 className="mb-6 text-white flex items-center gap-2">
                      <Zap size={20} className="text-[#C0FF00]" />
                      Energy Flow
                    </h4>

                    {/* Circular Gauge */}
                    <div className="relative w-64 h-64 mx-auto mb-6">
                      <svg className="w-full h-full" viewBox="0 0 200 200">
                        {/* Background Circle */}
                        <circle
                          cx="100"
                          cy="100"
                          r="80"
                          fill="none"
                          stroke="rgba(255, 255, 255, 0.1)"
                          strokeWidth="20"
                        />
                        {/* Animated Progress Circle */}
                        <motion.circle
                          cx="100"
                          cy="100"
                          r="80"
                          fill="none"
                          stroke="url(#gradient)"
                          strokeWidth="20"
                          strokeLinecap="round"
                          strokeDasharray={`${2 * Math.PI * 80}`}
                          initial={{ strokeDashoffset: 2 * Math.PI * 80 }}
                          animate={{ 
                            strokeDashoffset: 2 * Math.PI * 80 * (1 - energyFlow / 100),
                            rotate: 0,
                          }}
                          transition={{ duration: 1 }}
                          style={{ transformOrigin: '100px 100px', transform: 'rotate(-90deg)' }}
                        />
                        <defs>
                          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#C0FF00" />
                            <stop offset="50%" stopColor="#FFB800" />
                            <stop offset="100%" stopColor="#00C2FF" />
                          </linearGradient>
                        </defs>
                      </svg>
                      {/* Center Value */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-5xl bg-gradient-to-r from-[#C0FF00] to-[#00C2FF] bg-clip-text text-transparent">
                          {energyFlow.toFixed(1)}%
                        </span>
                        <span className="text-gray-400 text-sm">Optimal</span>
                      </div>
                    </div>

                    {/* Real-time Graph */}
                    <div className="flex items-end gap-1 h-24">
                      {[...Array(30)].map((_, i) => {
                        const height = Math.random() * 60 + 40;
                        return (
                          <motion.div
                            key={i}
                            className="flex-1 bg-gradient-to-t from-[#C0FF00] to-[#00C2FF] rounded-t-sm relative"
                            initial={{ height: 0 }}
                            animate={{ height: `${height}%` }}
                            transition={{ 
                              duration: 0.5,
                              delay: i * 0.02,
                              repeat: Infinity,
                              repeatDelay: 2,
                            }}
                          >
                            <div className="absolute -top-1 left-0 right-0 h-1 bg-[#C0FF00] blur-sm"></div>
                          </motion.div>
                        );
                      })}
                    </div>
                  </div>
                </motion.div>

                {/* Side Metrics */}
                <div className="space-y-6">
                  {[
                    { icon: Activity, label: 'Grid Balance', value: gridBalance, unit: '%', color: '#00C2FF' },
                    { icon: TrendingUp, label: 'Efficiency', value: efficiency, unit: '%', color: '#C0FF00' },
                    { icon: Battery, label: 'Storage', value: 87, unit: '%', color: '#FFB800' },
                  ].map((metric, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1, duration: 0.6 }}
                      className="p-6 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-2xl hover:border-white/20 transition-all duration-300"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <metric.icon size={24} style={{ color: metric.color }} />
                        <span className="text-2xl text-white">{metric.value.toFixed(0)}{metric.unit}</span>
                      </div>
                      <div className="text-sm text-gray-400 mb-2">{metric.label}</div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full rounded-full"
                          style={{ backgroundColor: metric.color }}
                          initial={{ width: 0 }}
                          animate={{ width: `${metric.value}%` }}
                          transition={{ duration: 1, delay: 0.5 }}
                        />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Bottom Row - System Status */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { icon: Brain, label: 'AI Status', value: 'Active', color: '#C0FF00' },
                  { icon: Wifi, label: 'IoT Devices', value: '24 Online', color: '#00C2FF' },
                  { icon: CloudRain, label: 'Weather Sync', value: 'Connected', color: '#FFB800' },
                  { icon: Cpu, label: 'Processing', value: '1.2ms', color: '#C0FF00' },
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1, duration: 0.6 }}
                    className="p-4 bg-white/5 border border-white/10 rounded-xl"
                  >
                    <item.icon size={20} style={{ color: item.color }} className="mb-2" />
                    <div className="text-xs text-gray-500 mb-1">{item.label}</div>
                    <div className="text-white">{item.value}</div>
                  </motion.div>
                ))}
              </div>

              {/* Holographic Grid Overlay */}
              <div className="absolute inset-0 opacity-10 pointer-events-none">
                <div className="w-full h-full bg-[linear-gradient(rgba(192,255,0,0.3)_1px,transparent_1px),linear-gradient(90deg,rgba(192,255,0,0.3)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
              </div>

              {/* Corner Glows */}
              <div className="absolute -top-20 -left-20 w-40 h-40 bg-[#C0FF00]/20 rounded-full blur-[100px]"></div>
              <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-[#00C2FF]/20 rounded-full blur-[100px]"></div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="relative py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="mb-4 text-white">Intelligent Features</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Advanced technology working seamlessly to optimize your solar energy system
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Brain,
                title: 'AI Optimization',
                desc: 'Machine learning algorithms continuously analyze patterns and optimize energy production',
                color: '#C0FF00',
              },
              {
                icon: CloudRain,
                title: 'Weather Prediction',
                desc: 'Real-time weather data integration for proactive energy management',
                color: '#00C2FF',
              },
              {
                icon: Activity,
                title: 'Predictive Maintenance',
                desc: 'AI detects potential issues before they occur, minimizing downtime',
                color: '#FFB800',
              },
              {
                icon: Wifi,
                title: 'IoT Integration',
                desc: 'Seamlessly connect all your energy devices in one unified ecosystem',
                color: '#C0FF00',
              },
              {
                icon: TrendingUp,
                title: 'Performance Analytics',
                desc: 'Detailed insights and reports on system performance and savings',
                color: '#00C2FF',
              },
              {
                icon: Zap,
                title: 'Smart Grid Sync',
                desc: 'Automatic load balancing and peak shaving for maximum efficiency',
                color: '#FFB800',
              },
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                className="group relative p-8 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-3xl hover:border-white/20 transition-all duration-500 overflow-hidden"
              >
                {/* Hover Glow */}
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background: `radial-gradient(circle at center, ${feature.color}10, transparent 70%)`,
                  }}
                />

                <div className="relative z-10">
                  <div
                    className="inline-flex p-4 rounded-2xl mb-6 border group-hover:shadow-[0_0_30px] transition-all duration-500"
                    style={{
                      backgroundColor: `${feature.color}15`,
                      borderColor: `${feature.color}30`,
                      boxShadow: `0 0 0 ${feature.color}00`,
                    }}
                  >
                    <feature.icon size={32} style={{ color: feature.color }} />
                  </div>
                  <h3 className="mb-3 text-white">{feature.title}</h3>
                  <p className="text-gray-400">{feature.desc}</p>
                </div>

                {/* Animated Corner */}
                <div
                  className="absolute top-0 right-0 w-24 h-24 opacity-0 group-hover:opacity-20 transition-opacity duration-500"
                  style={{
                    background: `radial-gradient(circle at top right, ${feature.color}, transparent)`,
                  }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
