import { motion } from 'motion/react';
import { ArrowRight, Zap, Users, TrendingUp, Battery } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';
import { useEffect, useState } from 'react';

export default function Home() {
  const [energyGenerated, setEnergyGenerated] = useState(47823);
  const [clientsPowered, setClientsPowered] = useState(1247);
  const [carbonOffset, setCarbonOffset] = useState(12456);

  useEffect(() => {
    const interval = setInterval(() => {
      setEnergyGenerated(prev => prev + Math.floor(Math.random() * 10));
      setClientsPowered(prev => prev + (Math.random() > 0.95 ? 1 : 0));
      setCarbonOffset(prev => prev + Math.floor(Math.random() * 5));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A1A]">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative h-screen overflow-hidden">
        {/* Animated 3D Solar Grid Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A1A] via-transparent to-[#0A0A1A] z-10"></div>
          
          {/* Grid Pattern with Animation */}
          <motion.div
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage: `
                linear-gradient(to right, rgba(192, 255, 0, 0.1) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(192, 255, 0, 0.1) 1px, transparent 1px)
              `,
              backgroundSize: '60px 60px',
              perspective: '1000px',
            }}
            animate={{
              backgroundPosition: ['0px 0px', '60px 60px'],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: 'linear',
            }}
          />

          {/* Rotating Solar Core */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <motion.div
              className="relative w-96 h-96"
              animate={{ rotate: 360 }}
              transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
            >
              {/* Core */}
              <div className="absolute inset-0 rounded-full bg-gradient-radial from-[#FFB800] via-[#C0FF00] to-transparent opacity-40 blur-3xl"></div>
              
              {/* Orbiting Elements */}
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-3 h-3 bg-[#C0FF00] rounded-full"
                  style={{
                    top: '50%',
                    left: '50%',
                    transformOrigin: '0 0',
                  }}
                  animate={{
                    rotate: [0, 360],
                    x: Math.cos((i * Math.PI * 2) / 8) * 150,
                    y: Math.sin((i * Math.PI * 2) / 8) * 150,
                  }}
                  transition={{
                    rotate: { duration: 10, repeat: Infinity, ease: 'linear' },
                  }}
                >
                  <div className="w-full h-full rounded-full bg-[#C0FF00] shadow-[0_0_20px_rgba(192,255,0,0.8)]"></div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Floating Particles */}
          {[...Array(30)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-[#C0FF00] rounded-full"
              initial={{
                x: Math.random() * window.innerWidth,
                y: window.innerHeight + Math.random() * 100,
                opacity: 0,
              }}
              animate={{
                y: -100,
                opacity: [0, 1, 1, 0],
              }}
              transition={{
                duration: Math.random() * 10 + 10,
                repeat: Infinity,
                delay: Math.random() * 5,
                ease: 'linear',
              }}
            />
          ))}
        </div>

        {/* Content */}
        <div className="relative z-20 flex flex-col items-center justify-center h-full px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="space-y-8 max-w-5xl"
          >
            <motion.h1
              className="text-white"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.7 }}
            >
              <span className="block mb-4">Redefining Solar.</span>
              <span className="block bg-gradient-to-r from-[#FFB800] via-[#C0FF00] to-[#00C2FF] bg-clip-text text-transparent">
                Recharging the Future.
              </span>
            </motion.h1>

            <motion.p
              className="text-xl text-gray-300 max-w-3xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 1 }}
            >
              Smart, Sustainable, Infinite Energy
              <br />
              <span className="text-[#00C2FF]">Where cutting-edge technology meets renewable power</span>
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-6 justify-center pt-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.2 }}
            >
              <Link
                to="/projects"
                className="group relative px-8 py-4 bg-gradient-to-r from-[#C0FF00] to-[#FFB800] text-[#0A0A1A] rounded-xl overflow-hidden transition-all duration-300 hover:shadow-[0_0_40px_rgba(192,255,0,0.8)]"
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  Explore Our Projects
                  <ArrowRight className="group-hover:translate-x-2 transition-transform duration-300" size={20} />
                </span>
              </Link>
              
              <Link
                to="/contact"
                className="px-8 py-4 border-2 border-[#00C2FF] text-[#00C2FF] rounded-xl backdrop-blur-sm transition-all duration-300 hover:bg-[#00C2FF]/10 hover:shadow-[0_0_30px_rgba(0,194,255,0.6)]"
              >
                Get a Free Quote
              </Link>
            </motion.div>
          </motion.div>

          {/* Real-time Data Cards */}
          <motion.div
            className="absolute bottom-12 left-1/2 -translate-x-1/2 w-full max-w-5xl px-4"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.5 }}
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { icon: Zap, label: 'Energy Generated Today', value: energyGenerated.toLocaleString(), unit: 'kWh', color: '#C0FF00' },
                { icon: Users, label: 'Clients Powered', value: clientsPowered.toLocaleString(), unit: '+', color: '#00C2FF' },
                { icon: TrendingUp, label: 'Carbon Offset', value: carbonOffset.toLocaleString(), unit: 'tons', color: '#FFB800' },
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  className="relative p-6 bg-gradient-to-br from-white/10 to-white/5 border border-white/10 rounded-2xl backdrop-blur-xl"
                  whileHover={{ scale: 1.05, borderColor: 'rgba(192, 255, 0, 0.3)' }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.div
                    className="absolute inset-0 rounded-2xl"
                    animate={{
                      boxShadow: [
                        `0 0 20px ${stat.color}00`,
                        `0 0 40px ${stat.color}40`,
                        `0 0 20px ${stat.color}00`,
                      ],
                    }}
                    transition={{ duration: 3, repeat: Infinity }}
                  />
                  <div className="relative z-10 flex items-center gap-4">
                    <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
                      <stat.icon size={24} style={{ color: stat.color }} />
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">{stat.label}</div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl text-white">{stat.value}</span>
                        <span className="text-sm text-gray-500">{stat.unit}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Quick Features Section */}
      <section className="relative py-24 px-4 bg-gradient-to-b from-[#0A0A1A] to-[#0f0f24]">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="mb-4 bg-gradient-to-r from-[#C0FF00] to-[#00C2FF] bg-clip-text text-transparent">
              The Future is Powered by Innovation
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Experience solar energy like never before with our AI-driven, sustainable solutions
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Zap, title: 'AI Optimization', desc: 'Machine learning maximizes efficiency' },
              { icon: Battery, title: 'Smart Storage', desc: '24/7 power availability' },
              { icon: Users, title: 'Zero Carbon', desc: '100% renewable energy' },
              { icon: TrendingUp, title: 'Smart Installation', desc: 'Seamless integration' },
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                className="group p-8 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-2xl hover:border-[#C0FF00]/30 transition-all duration-300"
              >
                <div className="p-4 bg-[#C0FF00]/10 border border-[#C0FF00]/30 rounded-xl inline-block mb-4 group-hover:shadow-[0_0_30px_rgba(192,255,0,0.3)] transition-all duration-300">
                  <feature.icon size={28} className="text-[#C0FF00]" />
                </div>
                <h3 className="mb-2 text-white">{feature.title}</h3>
                <p className="text-gray-400">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
