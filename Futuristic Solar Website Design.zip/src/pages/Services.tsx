import { motion } from 'motion/react';
import { Home, Building2, Battery, Smartphone, ArrowRight, Check } from 'lucide-react';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';
import { Link } from 'react-router';

const services = [
  {
    icon: Home,
    title: 'Residential Solar',
    tagline: 'Power Your Home with Intelligence',
    description: 'Transform your home into an energy-independent haven with our custom residential solar solutions.',
    features: [
      'Custom system design for your roof',
      'AI-powered energy optimization',
      'Battery backup integration',
      '25-year performance warranty',
      'Smart home integration',
      'Real-time monitoring app',
    ],
    stats: { before: '100%', after: '15%', label: 'Grid Dependency' },
    gradient: 'from-[#C0FF00] to-[#FFB800]',
    borderColor: '#C0FF00',
  },
  {
    icon: Building2,
    title: 'Commercial & Industrial',
    tagline: 'Scale Your Business Sustainably',
    description: 'Reduce operational costs and carbon footprint with enterprise-grade solar installations.',
    features: [
      'Large-scale system design',
      'ROI-focused planning',
      'Tax incentive maximization',
      'Load balancing & peak shaving',
      'Corporate sustainability reporting',
      'Maintenance & monitoring',
    ],
    stats: { before: '45%', after: '5%', label: 'Energy Costs' },
    gradient: 'from-[#00C2FF] to-[#C0FF00]',
    borderColor: '#00C2FF',
  },
  {
    icon: Battery,
    title: 'Battery Storage',
    tagline: 'Energy On-Demand, Anytime',
    description: 'Store excess energy for use during peak hours or power outages with advanced battery systems.',
    features: [
      'Tesla Powerwall integration',
      'Grid-tie & off-grid options',
      'Automatic backup switching',
      'Time-of-use optimization',
      'Scalable capacity',
      'Weather-based predictions',
    ],
    stats: { before: '0 hrs', after: '48 hrs', label: 'Backup Power' },
    gradient: 'from-[#FFB800] to-[#C0FF00]',
    borderColor: '#FFB800',
  },
  {
    icon: Smartphone,
    title: 'Smart Monitoring & IoT',
    tagline: 'Your Energy, Under Control',
    description: 'Monitor and control your solar system from anywhere with our AI-powered platform.',
    features: [
      'Real-time production tracking',
      'Predictive maintenance alerts',
      'Weather-based forecasting',
      'Remote system control',
      'Energy usage analytics',
      'Mobile & web dashboard',
    ],
    stats: { before: '70%', after: '98%', label: 'System Efficiency' },
    gradient: 'from-[#00C2FF] to-[#FFB800]',
    borderColor: '#00C2FF',
  },
];

export default function Services() {
  return (
    <div className="min-h-screen bg-[#0A0A1A]">
      <Navigation />
      
      {/* Hero */}
      <section className="relative pt-32 pb-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="mb-6 text-white">
              <span className="block">Solar Solutions for</span>
              <span className="bg-gradient-to-r from-[#C0FF00] via-[#FFB800] to-[#00C2FF] bg-clip-text text-transparent">
                Every Need
              </span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              From residential installations to enterprise-grade systems, we deliver cutting-edge solar solutions powered by AI and innovation.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Cards */}
      <section className="relative py-16 px-4">
        <div className="max-w-7xl mx-auto space-y-24">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="group relative p-8 lg:p-12 bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-[3rem] overflow-hidden hover:border-white/20 transition-all duration-500">
                {/* Animated Background Glow */}
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                  style={{
                    background: `radial-gradient(circle at 50% 50%, ${service.borderColor}10, transparent 70%)`,
                  }}
                  animate={{
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                  }}
                />

                <div className="relative z-10 grid lg:grid-cols-2 gap-12 items-center">
                  {/* Left: Content */}
                  <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                    <div
                      className="inline-flex p-4 rounded-2xl mb-6 border group-hover:shadow-[0_0_40px] transition-all duration-500"
                      style={{
                        backgroundColor: `${service.borderColor}15`,
                        borderColor: `${service.borderColor}40`,
                        boxShadow: `0 0 0 ${service.borderColor}00`,
                      }}
                    >
                      <service.icon size={40} style={{ color: service.borderColor }} />
                    </div>

                    <h2 className="mb-3 text-white">{service.title}</h2>
                    <p className="text-xl text-[#C0FF00] mb-4">{service.tagline}</p>
                    <p className="text-gray-400 mb-8">{service.description}</p>

                    {/* Features List */}
                    <div className="grid sm:grid-cols-2 gap-3 mb-8">
                      {service.features.map((feature, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: i * 0.1, duration: 0.4 }}
                          className="flex items-start gap-2"
                        >
                          <Check size={16} className="text-[#C0FF00] mt-1 flex-shrink-0" />
                          <span className="text-gray-300 text-sm">{feature}</span>
                        </motion.div>
                      ))}
                    </div>

                    <Link
                      to="/contact"
                      className={`inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r ${service.gradient} text-[#0A0A1A] rounded-xl hover:shadow-[0_0_40px] transition-all duration-300`}
                      style={{ boxShadow: `0 0 0 ${service.borderColor}00` }}
                    >
                      Get Started
                      <ArrowRight size={20} />
                    </Link>
                  </div>

                  {/* Right: Stats Visualization */}
                  <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                    <div className="relative p-8 bg-gradient-to-br from-white/10 to-white/5 border border-white/20 rounded-3xl backdrop-blur-xl">
                      <h4 className="mb-8 text-center text-white">Energy Savings Comparison</h4>
                      
                      {/* Before/After Bars */}
                      <div className="space-y-8">
                        <div>
                          <div className="flex justify-between items-center mb-3">
                            <span className="text-gray-400">Before</span>
                            <span className="text-white">{service.stats.before}</span>
                          </div>
                          <div className="h-12 bg-white/5 rounded-xl overflow-hidden">
                            <motion.div
                              className="h-full bg-gradient-to-r from-red-500 to-orange-500"
                              initial={{ width: 0 }}
                              whileInView={{ width: service.stats.before }}
                              viewport={{ once: true }}
                              transition={{ duration: 1, delay: 0.5 }}
                            />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between items-center mb-3">
                            <span className="text-gray-400">After SolarNext</span>
                            <span className="text-[#C0FF00]">{service.stats.after}</span>
                          </div>
                          <div className="h-12 bg-white/5 rounded-xl overflow-hidden">
                            <motion.div
                              className={`h-full bg-gradient-to-r ${service.gradient} shadow-[0_0_20px]`}
                              style={{ boxShadow: `0 0 20px ${service.borderColor}80` }}
                              initial={{ width: 0 }}
                              whileInView={{ width: service.stats.after }}
                              viewport={{ once: true }}
                              transition={{ duration: 1, delay: 0.8 }}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="mt-6 text-center">
                        <span className="text-gray-500">{service.stats.label}</span>
                      </div>

                      {/* Animated Particles */}
                      <div className="absolute inset-0 overflow-hidden pointer-events-none">
                        {[...Array(5)].map((_, i) => (
                          <motion.div
                            key={i}
                            className="absolute w-1 h-1 rounded-full"
                            style={{ backgroundColor: service.borderColor }}
                            initial={{
                              x: Math.random() * 100 + '%',
                              y: '100%',
                              opacity: 0,
                            }}
                            animate={{
                              y: '-10%',
                              opacity: [0, 1, 0],
                            }}
                            transition={{
                              duration: Math.random() * 2 + 2,
                              repeat: Infinity,
                              delay: Math.random() * 2,
                            }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Corner Glow */}
                <div
                  className="absolute -top-20 -right-20 w-40 h-40 rounded-full blur-[100px] opacity-20 group-hover:opacity-40 transition-opacity duration-700"
                  style={{ backgroundColor: service.borderColor }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-24 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative p-12 bg-gradient-to-br from-white/10 to-white/5 border border-[#C0FF00]/30 rounded-[3rem] overflow-hidden text-center"
          >
            <motion.div
              className="absolute inset-0"
              animate={{
                background: [
                  'radial-gradient(circle at 20% 50%, rgba(192, 255, 0, 0.1), transparent 50%)',
                  'radial-gradient(circle at 80% 50%, rgba(0, 194, 255, 0.1), transparent 50%)',
                  'radial-gradient(circle at 20% 50%, rgba(192, 255, 0, 0.1), transparent 50%)',
                ],
              }}
              transition={{ duration: 5, repeat: Infinity }}
            />
            
            <div className="relative z-10">
              <h2 className="mb-4 text-white">Ready to Go Solar?</h2>
              <p className="text-xl text-gray-300 mb-8">
                Let's design the perfect solar solution for your needs
              </p>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-10 py-4 bg-gradient-to-r from-[#C0FF00] to-[#00C2FF] text-[#0A0A1A] rounded-xl hover:shadow-[0_0_50px_rgba(192,255,0,0.8)] transition-all duration-300"
              >
                Get Your Free Consultation
                <ArrowRight size={20} />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
