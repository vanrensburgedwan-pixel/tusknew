import { motion } from 'motion/react';
import { Facebook, Twitter, Instagram, Linkedin, Sun } from 'lucide-react';

export function Footer() {
  const footerLinks = {
    company: [
      { label: 'About Us', href: '#' },
      { label: 'Our Team', href: '#' },
      { label: 'Careers', href: '#' },
      { label: 'Press', href: '#' },
    ],
    services: [
      { label: 'Residential', href: '#' },
      { label: 'Commercial', href: '#' },
      { label: 'Battery Storage', href: '#' },
      { label: 'Monitoring', href: '#' },
    ],
    resources: [
      { label: 'Blog', href: '#' },
      { label: 'Case Studies', href: '#' },
      { label: 'Documentation', href: '#' },
      { label: 'Support', href: '#' },
    ],
  };

  const socialLinks = [
    { icon: Facebook, href: '#', color: '#C0FF00' },
    { icon: Twitter, href: '#', color: '#00C2FF' },
    { icon: Instagram, href: '#', color: '#C0FF00' },
    { icon: Linkedin, href: '#', color: '#00C2FF' },
  ];

  return (
    <footer className="relative bg-[#0A0A1A] border-t border-[#C0FF00]/20">
      {/* Neon Line Divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#C0FF00] to-transparent"></div>

      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Column */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2"
          >
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 bg-gradient-to-br from-[#C0FF00]/20 to-transparent border border-[#C0FF00]/30 rounded-lg">
                <Sun size={28} className="text-[#C0FF00]" />
              </div>
              <span className="text-xl text-white">SolarNext</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-xs">
              Leading the renewable energy revolution with intelligent solar solutions 
              for a sustainable tomorrow.
            </p>
            
            {/* Social Links */}
            <div className="flex gap-4">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.4 }}
                  whileHover={{ scale: 1.1, y: -3 }}
                  className="p-3 bg-white/5 border border-white/10 rounded-lg hover:border-[#C0FF00]/30 transition-all duration-300 group"
                >
                  <social.icon 
                    size={20} 
                    className="text-gray-400 group-hover:text-[#C0FF00] transition-colors duration-300"
                  />
                </motion.a>
              ))}
            </div>
          </motion.div>

          {/* Links Columns */}
          {Object.entries(footerLinks).map(([category, links], columnIndex) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: columnIndex * 0.1, duration: 0.6 }}
            >
              <h4 className="mb-4 text-white capitalize">
                {category}
              </h4>
              <ul className="space-y-3">
                {links.map((link, index) => (
                  <li key={index}>
                    <a
                      href={link.href}
                      className="text-gray-400 hover:text-[#C0FF00] transition-colors duration-300 flex items-center gap-2 group"
                    >
                      <span className="w-0 h-px bg-[#C0FF00] group-hover:w-4 transition-all duration-300"></span>
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Newsletter Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12 p-8 bg-gradient-to-r from-white/5 to-transparent border border-[#C0FF00]/20 rounded-2xl"
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h4 className="mb-2 text-white">Stay Updated</h4>
              <p className="text-gray-400">
                Get the latest news on solar technology and sustainable energy
              </p>
            </div>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:border-[#C0FF00] focus:outline-none focus:ring-2 focus:ring-[#C0FF00]/20 transition-all duration-300"
              />
              <button className="px-6 py-3 bg-[#C0FF00] text-[#0A0A1A] rounded-lg hover:shadow-[0_0_20px_rgba(192,255,0,0.5)] transition-all duration-300">
                Subscribe
              </button>
            </div>
          </div>
        </motion.div>

        {/* Bottom Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="pt-8 border-t border-white/10"
        >
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
            <p>© 2025 SolarNext. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-[#C0FF00] transition-colors duration-300">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-[#C0FF00] transition-colors duration-300">
                Terms of Service
              </a>
              <a href="#" className="hover:text-[#C0FF00] transition-colors duration-300">
                Cookie Policy
              </a>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom Glow Effect */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/2 h-px bg-gradient-to-r from-transparent via-[#00C2FF]/50 to-transparent"></div>
    </footer>
  );
}
